'use strict';

// const plusBtn = document.getElementById('plus');

// plusBtn.addEventListener('click', function(){
  //  const inputValue = document.getElementById('input').value;
  //  const newBtn = parseInt(inputValue);
  //  const total = newBtn+1;
  //  document.getElementById('input').value = total;
//   productCount(true)
// })
 
// const minusBtn = document.getElementById('minus');

// minusBtn.addEventListener('click', function(){
  //  const inputValue = document.getElementById('input').value;
  //  const newBtn = parseInt(inputValue);
  //  const total = newBtn-1;
  //  document.getElementById('input').value = total;
//   productCount(false)
// })

function productCount(product){
  const inputValue = document.getElementById('input').value;
   const newBtn = parseInt(inputValue);
  //  const total = newBtn-1;
  let total =  newBtn;

  if(product == true){
    total = newBtn+1;
  }

  if(product == false && newBtn > 0 ){
    total = newBtn-1;
  }

   document.getElementById('input').value = total;
   document.getElementById('quantity').innerHTML = total;
   
}

const buyNow = document.getElementById('buy');
  addEventListener('click', function(){
    const inputValue = document.getElementById('quantity').innerHTML = document.getElementById('input').value;
    const newBtn = parseInt(inputValue);
  // const totalAmount = document.getElementById('total-ammount');
   
  const total = newBtn * 50;
  document.getElementById('total-ammount').innerText = total;

})





 




